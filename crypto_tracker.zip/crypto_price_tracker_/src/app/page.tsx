'use client'
import Image from "next/image";
import CryptoTable from "./components/table";
import { useDispatch, useSelector } from "react-redux";
import { useState } from "react";
import { AppDispatch, RootState } from "@/lib/redux/store";
import { setSymbol } from "@/lib/redux/slices/cryptoSlice";

export default function Home() {

  const [isModalOpen, setIsModalOpen] = useState(false);
  const symbol = useSelector((state: RootState) => state.crypto.symbol);
  const dispatch: AppDispatch = useDispatch();

  const handleChangeSymbol = (newSymbol: string) => {
    dispatch(setSymbol(newSymbol));
    setIsModalOpen(false);
  };
  return (
    <main className="flex min-h-screen flex-col items-center justify-between p-24">
   <div>
      <h1>Crypto Prices for {symbol}</h1>
      <button onClick={() => setIsModalOpen(true)}>Change Symbol</button>
      <CryptoTable />
      {isModalOpen && (
        <div className="modal">
          <div className="modal-content">
            <span className="close" onClick={() => setIsModalOpen(false)}>&times;</span>
            <input
              type="text"
              placeholder="Enter Symbol"
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleChangeSymbol(e.currentTarget.value);
                }
              }}
            />
          </div>
        </div>
      )}
    </div>
    </main>
  );
}
