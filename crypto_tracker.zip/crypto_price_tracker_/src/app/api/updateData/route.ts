import { NextRequest, NextResponse } from 'next/server';
import { fetchDataAndStore } from '../../../lib/service';

export async function GET(request: NextRequest) {
  try {
    const data = await fetchDataAndStore();
    return NextResponse.json(data);
  } catch (error:any) {
    return NextResponse.json({ message: error.message }, { status: 500 });
  }
}