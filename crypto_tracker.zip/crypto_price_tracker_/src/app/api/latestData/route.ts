import { NextRequest, NextResponse } from 'next/server';
import { connectDB } from '@/lib/dbConnection';
import CryptodataModel from '@/lib/model/crypto';

export async function GET(request: NextRequest) {
  await connectDB();

  try {
    const data = await CryptodataModel.find({})
      .sort({ timestamp: -1 })
      .limit(20)
      .exec();

    return NextResponse.json(data);
  } catch (error: any) {
    console.error('Failed to fetch latest data:', error);
    return NextResponse.json({ message: 'Failed to fetch latest data', error: error.message }, { status: 500 });
  }
}