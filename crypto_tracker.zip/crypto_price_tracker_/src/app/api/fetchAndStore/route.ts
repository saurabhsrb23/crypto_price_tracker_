import { NextRequest, NextResponse } from 'next/server';
import axios from 'axios';
import { API_KEY, API_URL, connectDB } from '@/lib/dbConnection';
import CryptodataModel from '@/lib/model/crypto';
import { CryptoData } from '@/lib/instances/instances';



export async function GET(request: NextRequest) {
  await connectDB();

  try {
    const response = await axios.post<CryptoData[]>(
      API_URL,
      {
        currency: 'USD',
        sort: 'rank',
        order: 'ascending',
        offset: 0,
        limit: 10,
        meta: true,
      },
      {
        headers: {
          'content-type': 'application/json',
          'x-api-key': API_KEY,
        },
      }
    );

    const res = response.data.map(item => ({
      name: item.name || '',
      png32: item.png32 || '',
      rank: item.rank || 0,
      rate: item.rate || 0,
      allTimeHighUSD: item.allTimeHighUSD || 0,
      circulatingSupply: item.circulatingSupply || 0,
      totalSupply: item.totalSupply || 0,
      maxSupply: item.maxSupply ?? null,
      volume: item.volume || 0,
      cap: item.cap || 0,
      timestamp: new Date(),
    }));

    const invalidData = res.filter(item => !item.name || !item.rank);
    if (invalidData.length > 0) {
      console.error('Validation failed for the following data:', invalidData);
      return NextResponse.json({ message: 'Validation failed', invalidData }, { status: 400 });
    }

    await CryptodataModel.insertMany(res);

    return NextResponse.json(res);
  } catch (error:any) {
    console.error('Failed to fetch data:', error);
    return NextResponse.json({ message: 'Failed to fetch data', error: error.message }, { status: 500 });
  }
}

