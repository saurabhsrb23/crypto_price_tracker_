"use client";

import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { fetchCryptoData } from '@/lib/redux/slices/cryptoSlice';
import type { RootState, AppDispatch } from '@/lib/redux/store';

const CryptoTable = () => {
  const dispatch: AppDispatch = useDispatch();
  const { data, status, error, symbol } = useSelector((state: RootState) => state.crypto);

  useEffect(() => {
    const fetchData = () => {
      dispatch(fetchCryptoData(symbol));
    };

    fetchData();

    const id = setInterval(fetchData, 1000);

    return () => clearInterval(id);
  }, [dispatch, symbol]);

  if (status === 'loading') {
    return <div>Loading...</div>;
  }

  if (status === 'failed') {
    return <div>Error: {error}</div>;
  }

  return (
    <table>
      <thead>
        <tr>
          <th>Name</th>
          <th>Image</th>
          <th>Rank</th>
          <th>Rate</th>
          <th>All Time High USD</th>
          <th>Circulating Supply</th>
          <th>Total Supply</th>
          <th>Max Supply</th>
          <th>Volume</th>
          <th>Cap</th>
          <th>Timestamp</th>
        </tr>
      </thead>
      <tbody>
        {data.map((crypto) => (
          <tr key={crypto._id}>
            <td>{crypto.name}</td>
            <td><img src={crypto.png32} alt={crypto.name} /></td>
            <td>{crypto.rank}</td>
            <td>{crypto.rate}</td>
            <td>{crypto.allTimeHighUSD}</td>
            <td>{crypto.circulatingSupply}</td>
            <td>{crypto.totalSupply}</td>
            <td>{crypto.maxSupply !== null ? crypto.maxSupply : 'N/A'}</td>
            <td>{crypto.volume}</td>
            <td>{crypto.cap}</td>
            <td>{new Date(crypto.timestamp).toLocaleString()}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default CryptoTable;
