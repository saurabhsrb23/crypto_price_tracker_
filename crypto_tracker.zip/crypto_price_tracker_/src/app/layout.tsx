import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import '@/lib/cron'; 
import { Provider } from "react-redux";
import store from "@/lib/redux/store";
const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Crypto Tracker",
  description: "Real time crypto tracker",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <Provider store={store}>

      <body className={inter.className}>{children}</body>
      </Provider>
    </html>
  );
}
