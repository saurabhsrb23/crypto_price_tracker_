import mongoose, { Schema } from 'mongoose';
import { CryptoData } from '../instances/instances';

const CryptoSchema = new Schema<CryptoData>({
  name: { type: String, required: true },
  png32: { type: String, required: true },
  rank: { type: Number, required: true },
  rate: { type: Number, required: true },
  allTimeHighUSD: { type: Number, required: true },
  circulatingSupply: { type: Number, required: true },
  totalSupply: { type: Number, required: true },
  maxSupply: { type: Number }, 
  volume: { type: Number, required: true },
  cap: { type: Number, required: true },
  timestamp: { type: Date, default: Date.now },
});

const CryptodataModel = mongoose.models.CryptodataModel || mongoose.model<CryptoData>('CryptodataModel', CryptoSchema);

export default CryptodataModel;