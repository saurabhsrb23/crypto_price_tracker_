import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

export type CryptoData = {
  _id: string;
  name: string;
  png32: string;
  rank: number;
  rate: number;
  allTimeHighUSD: number;
  circulatingSupply: number;
  totalSupply: number;
  maxSupply: number | null;
  volume: number;
  cap: number;
  timestamp: string;
};

const initialState = {
  data: [] as CryptoData[],
  status: 'idle' as 'idle' | 'loading' | 'succeeded' | 'failed',
  error: null as string | null,
  symbol: 'BTC', // Default symbol
};

export const fetchCryptoData = createAsyncThunk(
  'crypto/fetchData',
  async (symbol: string) => {
    const response = await axios.get(`/api/latestData?symbol=${symbol}`);
    return response.data as CryptoData[];
  }
);

const cryptoSlice = createSlice({
  name: 'crypto',
  initialState,
  reducers: {
    setSymbol(state, action) {
      state.symbol = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchCryptoData.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchCryptoData.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.data = action.payload;
      })
      .addCase(fetchCryptoData.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message || 'Failed to fetch data';
      });
  },
});

export const { setSymbol } = cryptoSlice.actions;

export default cryptoSlice.reducer;
