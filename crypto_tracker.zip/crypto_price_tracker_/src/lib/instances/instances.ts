import { Document } from "mongoose";

export interface CryptoData extends Document {
  name: string;
  png32: string;
  rank: number;
  rate: number;
  allTimeHighUSD: number;
  circulatingSupply: number;
  totalSupply: number;
  maxSupply?: number; 
  volume: number;
  cap: number;
  timestamp?: Date; 
}

export  type responceInterface = {
  _id: string;
  name: string;
  png32: string;
  rank: number;
  rate: number;
  allTimeHighUSD: number;
  circulatingSupply: number;
  totalSupply: number;
  maxSupply: number | null;
  volume: number;
  cap: number;
  timestamp: string;
};