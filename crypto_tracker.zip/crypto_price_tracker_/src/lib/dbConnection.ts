


export const dbConfig:string =process.env.MONGODB_URI || ''
export const API_KEY:string =process.env.API_KEY || ''
export const API_URL:string ='https://api.livecoinwatch.com/coins/list'

import mongoose from 'mongoose';


const connectDB = async (): Promise<void> => {
  if (mongoose.connections[0].readyState) {
    return;
  }
  await mongoose.connect(dbConfig);
};

export { connectDB};

