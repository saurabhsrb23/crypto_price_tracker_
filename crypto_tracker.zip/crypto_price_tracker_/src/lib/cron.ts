import cron from 'node-cron';
import { fetchDataAndStore } from './service';

cron.schedule('*/1 * * * * *', async () => {
  try {    
    await fetchDataAndStore();
    console.log('Scheduled task executed successfully');
  } catch (error) {
    console.error('Failed to execute scheduled task:', error);
  }
});

export default {};