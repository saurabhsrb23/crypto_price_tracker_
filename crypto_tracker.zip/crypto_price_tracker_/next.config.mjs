/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ['api.livecoinwatch.com'],
      }
};

export default nextConfig;
